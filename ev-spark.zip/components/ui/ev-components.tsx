'use client'

import CountUpLib from 'react-countup'
import { AnimatePresence, motion, useScroll, useSpring } from 'framer-motion'
import Link from 'next/link'
import { ArrowRight, BatteryCharging, Check, ChevronDown, Menu, X, Zap } from 'lucide-react'
import { useEffect, useState } from 'react'

export function EVButton({ children, variant = 'primary', href = '#connect' }: { children: React.ReactNode; variant?: 'primary' | 'ghost'; href?: string }) {
  return <a href={href} className={`ev-button ${variant === 'ghost' ? 'ev-button-ghost' : ''}`}>{children}<ArrowRight size={17} /></a>
}

export function EVNavbar() {
  const [open, setOpen] = useState(false)
  const { scrollY } = useScroll()
  const [scrolled, setScrolled] = useState(false)
  const smooth = useSpring(scrollY, { stiffness: 100, damping: 30 })
  useEffect(() => smooth.on('change', value => setScrolled(value > 20)), [smooth])
  const links = [['Features', '#features'], ['How It Works', '#how'], ['For Operators', '#roles'], ['For Drivers', '#roles'], ['About', '#ecosystem']]
  return <header className={`ev-nav ${scrolled ? 'ev-nav-scrolled' : ''}`}><a href="#top" className="brand"><span className="brand-mark"><Zap size={18} fill="currentColor" /></span><span><b>EV</b><em>spark</em></span></a><nav className="desktop-nav">{links.map(([label, href]) => <a key={label} href={href}>{label}</a>)}</nav><div className="nav-actions"><Link className="sign-in" href="/auth/login">Sign In</Link><Link className="ev-button" href="/auth/register">Get Started <ArrowRight size={17} /></Link></div><button className="mobile-menu" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button><AnimatePresence>{open && <motion.nav initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="mobile-nav">{links.map(([label, href]) => <a key={label} href={href} onClick={() => setOpen(false)}>{label}</a>)}<Link className="ev-button" href="/auth/register" onClick={() => setOpen(false)}>Get Started <ArrowRight size={17} /></Link></motion.nav>}</AnimatePresence></header>
}

export function Reveal({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) { return <motion.div className={className} initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-80px' }} transition={{ duration: .6, delay }}>{children}</motion.div> }
export function SectionHeading({ eyebrow, title, copy }: { eyebrow: string; title: string; copy: string }) { return <div className="section-heading"><span className="eyebrow">{eyebrow}</span><h2>{title}</h2><p>{copy}</p></div> }
export function CountUp({ end, suffix = '', prefix = '' }: { end: number; suffix?: string; prefix?: string }) { return <CountUpLib end={end} prefix={prefix} suffix={suffix} enableScrollSpy scrollSpyOnce duration={1.8} separator="," /> }
export function CheckItem({ children }: { children: React.ReactNode }) { return <li><span className="check"><Check size={14} /></span>{children}</li> }
export function ChargingIcon() { return <div className="charging-icon"><BatteryCharging size={25} /></div> }
export function RoleGuard({ active, onChange }: { active: string; onChange: (role: string) => void }) { return <div className="role-tabs">{['Drivers', 'Operators', 'Admins'].map(role => <button key={role} className={active === role ? 'active' : ''} onClick={() => onChange(role)}>{role}<ChevronDown size={14} /></button>)}</div> }
export function EVFooter() { return <footer className="footer"><div><a href="#top" className="brand footer-brand"><span className="brand-mark"><Zap size={18} fill="currentColor" /></span><span><b>EV</b><em>spark</em></span></a><p>Power Your Journey, Intelligently</p><div className="socials"><a href="#twitter">𝕏</a><a href="#linkedin">in</a><a href="#github">◖</a></div></div><div><h4>Product</h4><a href="#features">Features</a><a href="#map">Station Map</a><a href="#dashboard">Analytics</a><a href="#api">API Docs</a></div><div><h4>Company</h4><a href="#about">About</a><a href="#careers">Careers</a><a href="#blog">Blog</a><a href="#press">Press</a></div><div><h4>Legal</h4><a href="#privacy">Privacy Policy</a><a href="#terms">Terms of Service</a><a href="#cookies">Cookie Policy</a></div><div className="footer-bottom"><span>© 2025 EVspark Technologies Pvt. Ltd.</span><span>Made in India · OCPP Compatible · FAME II Aligned</span></div></footer> }
export const fadeUp = { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { duration: .6 } }

