'use client'

import { useEffect } from 'react'
import { CircleMarker, MapContainer, TileLayer, useMap } from 'react-leaflet'
import type { Station } from '@/components/dashboard/stations'
import L from 'leaflet'

function MapFocus({ station }: { station: Station | null }) {
  const map = useMap()
  useEffect(() => {
    if (station) map.flyTo([station.lat, station.lng], 13, { duration: 0.65 })
  }, [map, station])
  return null
}

const statusColors = { available: '#10b981', busy: '#f59e0b', offline: '#94a3b8' }

export function MapComponent({ stations, selectedStation, onSelect }: { stations: Station[]; selectedStation: Station | null; onSelect: (station: Station) => void }) {
  return <MapContainer center={[19.076, 72.8777]} zoom={11} zoomControl={false} className="leaflet-map" attributionControl={false}>
    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
    <MapFocus station={selectedStation} />
    {stations.map((station) => <CircleMarker key={station.id} center={[station.lat, station.lng]} radius={station.id === selectedStation?.id ? 13 : 9} pathOptions={{ color: '#fff', weight: 3, fillColor: statusColors[station.status], fillOpacity: 1 }} eventHandlers={{ click: () => onSelect(station) }} />)}
  </MapContainer>
}

export function getStationIcon(station: Station) {
  return L.divIcon({ className: 'station-icon', html: `<span style="background:${statusColors[station.status]}"></span>` })
}
