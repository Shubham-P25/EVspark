'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Eye, EyeOff, Zap } from 'lucide-react'
import { useState } from 'react'
import { AuthField, AuthLeftPanel, AuthSubmit } from '@/components/auth/auth-left-panel'

export default function LoginPage() { const router = useRouter(); const [show,setShow]=useState(false)
  return <main className="auth-shell"><AuthLeftPanel /><section className="auth-form-panel"><div className="auth-form-inner"><p className="auth-top-link">Don&apos;t have an account? <Link href="/auth/register">Sign up free</Link></p><motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{duration:.45}}><div className="auth-title-mark"><Zap size={18} fill="currentColor" /></div><h1>Welcome back</h1><p className="auth-subtitle">Sign in to your EVspark account</p></motion.div><div className="auth-form-fields"><AuthField label="Email address" type="email" placeholder="you@example.com" autoComplete="email" /><label className="auth-field"><span className="label-row"><b>Password</b><Link href="/auth/forgot-password">Forgot password?</Link></span><div className="password-wrap"><input type={show?'text':'password'} placeholder="Enter your password" autoComplete="current-password" /><button type="button" aria-label={show?'Hide password':'Show password'} onClick={()=>setShow(!show)}>{show?<EyeOff size={18}/>:<Eye size={18}/>}</button></div></label><AuthSubmit onClick={()=>router.push('/auth/onboarding')}>Sign In <span>→</span></AuthSubmit></div><SocialButtons /><p className="auth-terms">By signing in, you agree to our <Link href="#terms">Terms of Service</Link> and <Link href="#privacy">Privacy Policy</Link></p></div></section></main>
}

function SocialButtons(){return <><div className="auth-divider"><span>or continue with</span></div><div className="social-row"><button type="button"><span className="google-mark">G</span>Google</button><button type="button"><span className="google-mark">GH</span>GitHub</button></div></>}
